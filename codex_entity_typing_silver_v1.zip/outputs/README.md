Место для ответов Codex: один файл outputs/batch_NNN.jsonl на каждый batches/batch_NNN.json. Не изменяйте исходные batches.
