#!/usr/bin/env python3
import argparse,collections,json,pathlib
from validate import inspect

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path('.'));a=ap.parse_args()
    m,done,total,rows,errors=inspect(a.root)
    if errors or done!=total:raise SystemExit(f'Merge refused: {done}/{total}; errors={errors[:8]}')
    key={r['candidate_id']:r for r in rows}
    expected=[cid for b in m['batches'] for cid in b['candidate_ids']]
    assert len(key)==len(expected)==m['candidate_count']
    p=a.root/'silver_labels_1211.jsonl'
    p.write_text(''.join(json.dumps(key[cid],ensure_ascii=False,sort_keys=True)+'\n' for cid in expected),encoding='utf-8')
    summary={'protocol':m['protocol'],'count':len(rows),'batch_count':len(m['batches']),
             'by_status':dict(collections.Counter(r['typing_status'] for r in rows)),
             'by_type':dict(collections.Counter((r.get('entity_type') or r['typing_status']) for r in rows)),
             'by_confidence':dict(collections.Counter(r['confidence'] for r in rows)),
             'label_provenance':'LLM_SILVER_NOT_HUMAN_GOLD'}
    (a.root/'silver_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Wrote:',p,'and silver_summary.json')
if __name__=='__main__':main()
