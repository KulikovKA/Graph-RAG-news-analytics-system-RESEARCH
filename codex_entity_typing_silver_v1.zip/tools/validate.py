#!/usr/bin/env python3
import argparse,collections,json,pathlib,sys
TYPES={"OBJECT","ACTOR","CONCEPT","METHOD","PROCESS","DATA_RESOURCE","ATTRIBUTE","RESULT","CONDITION","TASK","MECHANISM"}
STATUSES={"TYPED","UNKNOWN","NON_ENTITY"}
CONF={"HIGH","MEDIUM","LOW"}

def inspect(root,batch_id=None):
    m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    errors=[];completed=0;total=0;labels=[]
    batches=[b for b in m['batches'] if not batch_id or b['batch_id']==batch_id]
    if not batches:raise ValueError('unknown batch ID')
    for b in batches:
        content=(root/b['file']).read_bytes()
        import hashlib
        if hashlib.sha256(content).hexdigest()!=b['file_sha256']:
            errors.append(f"{b['batch_id']}: input batch hash changed")
        source=json.loads(content)
        if [x['candidate_id'] for x in source['candidates']]!=b['candidate_ids']:
            errors.append(f"{b['batch_id']}: manifest candidate IDs mismatch")
        for x in source['candidates']:
            if source['source_text'][x['start']:x['end']]!=x['surface_text']:
                errors.append(f"{b['batch_id']}: offset mismatch for {x['candidate_id']}")
        total+=b['count']
        p=root/'outputs'/f"{b['batch_id']}.jsonl"
        if not p.exists():continue
        parsed=[];fail=False
        for lineno,line in enumerate(p.read_text(encoding='utf-8').splitlines(),start=1):
            if not line.strip():continue
            try:d=json.loads(line)
            except Exception as e:errors.append(f"{p.name}:{lineno} invalid JSON: {e}");fail=True;continue
            if not isinstance(d,dict):errors.append(f"{p.name}:{lineno} must be object");fail=True;continue
            k=d.get('candidate_id');status=d.get('typing_status');ty=d.get('entity_type')
            if status not in STATUSES:errors.append(f"{p.name}:{lineno} bad status");fail=True
            if status=='TYPED' and ty not in TYPES:errors.append(f"{p.name}:{lineno} bad typed class");fail=True
            if status in {'UNKNOWN','NON_ENTITY'} and ty is not None:errors.append(f"{p.name}:{lineno} non-null type for {status}");fail=True
            if d.get('confidence') not in CONF:errors.append(f"{p.name}:{lineno} invalid confidence");fail=True
            if not isinstance(d.get('reason'),str) or not d['reason'].strip():errors.append(f"{p.name}:{lineno} missing reason");fail=True
            parsed.append(d)
        ids=[x.get('candidate_id') for x in parsed]
        expected=set(b['candidate_ids']);seen=set(ids)
        if set(ids)!=expected:errors.append(f"{p.name}: missing={len(expected-seen)} unexpected={len(seen-expected)}");fail=True
        if len(ids)!=len(set(ids)):errors.append(f"{p.name}: duplicated IDs");fail=True
        if len(parsed)!=b['count']:errors.append(f"{p.name}: count expected {b['count']} got {len(parsed)}");fail=True
        if not fail:completed+=b['count'];labels.extend(parsed)
    return m,completed,total,labels,errors

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path('.'));ap.add_argument('--batch');ap.add_argument('--require-complete',action='store_true');a=ap.parse_args()
    m,done,total,rows,errors=inspect(a.root,a.batch)
    print(f"Valid completed candidates: {done}/{total}; batches total: {len(m['batches'])}; errors: {len(errors)}")
    for e in errors[:30]:print('ERROR:',e,file=sys.stderr)
    if len(errors)>30:print(f'... plus {len(errors)-30} more errors',file=sys.stderr)
    if errors or (a.require_complete and done!=total):sys.exit(1)
if __name__=='__main__':main()
